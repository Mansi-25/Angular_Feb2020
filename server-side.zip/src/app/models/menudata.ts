import {Menu, SubMenu} from './menu'
import { RouterLink } from '@angular/router';
export let menuData: Menu[]=[
    new Menu('Account Summary', 'pi pi-fw pi-plus', 'AccountSummary', [new SubMenu('Transactions', 'pi pi-arrow-right', 'AccountSummary/Transaction')]),
    new Menu('Requests', 'pi pi-fw pi-plus', 'Request', [new SubMenu('Cheque Request', 'pi pi-arrow-right', 'Request/Cheque'), new SubMenu('Address Request', 'pi pi-arrow-right', 'Request/Address') ]),
    new Menu('Fund Transfer', 'pi pi-fw pi-plus', 'FundTransfer', [new SubMenu('NEFT', 'pi pi-arrow-right', 'FundTransfer/NEFT'), new SubMenu('IMPS', 'pi pi-arrow-right', 'FundTransfer/IMPS'), new SubMenu('RTGS', 'pi pi-arrow-right', 'FundTransfer/RTGS')]),
];