export class Menu{
    private _label: string;
    public get label(): string {
        return this._label;
    }
    public set label(value: string) {
        this._label = value;
    }
    private _icon: string;
    public get icon(): string {
        return this._icon;
    }
    public set icon(value: string) {
        this._icon = value;
    }
    private _routerLink: string;
    public get routerLink(): string {
        return this._routerLink;
    }
    public set routerLink(value: string) {
        this._routerLink = value;
    }
    private _items: SubMenu[];
    public get items(): SubMenu[] {
        return this._items;
    }
    public set items(value: SubMenu[]) {
        this._items = value;
    }
    constructor(label: string, icon: string, routerLink: string, items: SubMenu[]) {
        this._label = label;
        this._icon = icon;
        this._routerLink = routerLink;
        this._items = items;
    }
}
export class SubMenu{
    private _label: string;
    public get label(): string {
        return this._label;
    }
    public set label(value: string) {
        this._label = value;
    }
    private _icon: string;
    public get icon(): string {
        return this._icon;
    }
    public set icon(value: string) {
        this._icon = value;
    }
    private _routerLink: string;
    public get routerLink(): string {
        return this._routerLink;
    }
    public set routerLink(value: string) {
        this._routerLink = value;
    }
    private _items: [];
    public get items(): [] {
        return this._items;
    }
    public set items(value: []) {
        this._items = value;
    }
    constructor(label: string, icon: string, routerLink: string) {
        this._label = label;
        this._icon = icon;
        this._routerLink = routerLink;
    }    
}