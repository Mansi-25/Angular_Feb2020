import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddressrequestComponent } from './addressrequest.component';

describe('AddressrequestComponent', () => {
  let component: AddressrequestComponent;
  let fixture: ComponentFixture<AddressrequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddressrequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
