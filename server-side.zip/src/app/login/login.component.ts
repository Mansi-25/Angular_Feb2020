import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import {MenuService} from '../services/menu.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = new User( "", "");
  constructor(private loginService: LoginService, private router: Router, private authService: AuthService) { }

  ngOnInit() {
  }
  login (event){
    event.preventDefault();
    console.log(this.user);
    this.loginService.checkUserExistence(this.user).subscribe(response=>{
      console.log(response);
      if(response.email!=null){
        this.authService.token=response.email;
      }
      //console.log(this.authService.isLoggedIn);
      if(this.authService.isLoggedIn){
        
        this.router.navigate(["/home"]);
      }
      else{
        this.router.navigate(["/login"]);
      }
    })
    this.newUser();
  }
  newUser() {
    this.user = new User('','');
  }
}
