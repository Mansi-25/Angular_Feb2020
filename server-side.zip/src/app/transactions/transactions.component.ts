import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import * as opecData from '../../../opec.json'
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import { EditviewComponent } from './editview/editview.component';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit, AfterViewInit {
  
  @ViewChild(MatPaginator,{static:false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static:false}) sort: MatSort;
  //tableData: any ;
  tableSource = new MatTableDataSource();
  displayedColumns: string[]=['0','1','Edit','Delete'];
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    console.log(opecData.dataset.data);
    //this.tableData =  opecData.dataset.data;
    this.tableSource.data=opecData.dataset.data;
  }
  ngAfterViewInit(): void {
    this.tableSource.paginator=this.paginator;
    this.tableSource.sort=this.sort;
  }
  openDialog(obj){
      const dialogRef = this.dialog.open(EditviewComponent,{
        width: '500px',
        data: {
          date: obj[0],
          value: obj[1]
        }
      });
      dialogRef.afterClosed().subscribe(result=>{
        console.log('The dialog was closed');
        console.log(result);
      });
  }

}
