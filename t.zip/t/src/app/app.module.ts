import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field' ;
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { LoginService } from './services/login.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { MenuService } from './services/menu.service';
import { HomeComponent } from './home/home.component';
import {TieredMenuModule} from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { RequestsComponent } from './requests/requests.component';
import { ChequerequestComponent } from './chequerequest/chequerequest.component';
import { AddressrequestComponent } from './addressrequest/addressrequest.component';
import {MatTableModule} from '@angular/material/table';
import {MatSortModule} from '@angular/material/sort';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatDialogModule} from '@angular/material/dialog';
import { EditComponent } from './transactions/edit/edit.component';
import { EditviewComponent } from './transactions/editview/editview.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    TransactionsComponent,
    RequestsComponent,
    ChequerequestComponent,
    AddressrequestComponent,
    EditComponent,
    EditviewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule
  ],
  providers: [LoginService, AuthService, MenuService],
  entryComponents: [EditComponent,EditviewComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
