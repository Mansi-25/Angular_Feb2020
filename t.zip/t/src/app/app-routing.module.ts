import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { RequestsComponent } from './requests/requests.component';
import { ChequerequestComponent } from './chequerequest/chequerequest.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { AddressrequestComponent } from './addressrequest/addressrequest.component';

const routes: Routes = [{
  path: "login",
  component: LoginComponent
},
{
  path: "home",
  component: HomeComponent,
  children:[
    {
      path:"AccountSummary",
      component: AccountsummaryComponent,
      children:[{
        path: "Transaction",
        component: TransactionsComponent
      }]
    },
    {
      path: "Request",
      component: RequestsComponent,
      children:[{
        path: "Cheque",
        component: ChequerequestComponent
      },
      {
        path: "Address",
        component: AddressrequestComponent
      }
      ]
    },
    {
      path: 'FundTransfer',
      loadChildren: ()=> import ('./fundtransfer/fundtransfer.module').then (m => m.FundtransferModule)
    },    
  ]
},

{ path:'', 
  redirectTo:'/login', 
  pathMatch:'full'
},
{ path:'**', 
  redirectTo:'/login'
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
