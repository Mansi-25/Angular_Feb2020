import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chequerequest',
  templateUrl: './chequerequest.component.html',
  styleUrls: ['./chequerequest.component.css']
})
export class ChequerequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
