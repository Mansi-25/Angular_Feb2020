import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addressrequest',
  templateUrl: './addressrequest.component.html',
  styleUrls: ['./addressrequest.component.css']
})
export class AddressrequestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
