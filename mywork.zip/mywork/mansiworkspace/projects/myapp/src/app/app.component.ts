import { Component, OnInit } from '@angular/core';
import { UserService } from 'projects/util/src/lib/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'myapp';
  data:any;
  constructor(private userservice: UserService){

  }
  ngOnInit(){
      this.data=this.userservice.getData();
      console.log(this.data);
  }
}
