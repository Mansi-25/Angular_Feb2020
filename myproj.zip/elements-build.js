const fs = require('fs-extra');
const concat = require('concat');
(async function build() {
  const files = [
    './dist/myproj/runtime-es2015.js',
    './dist/myproj/polyfills-es2015.js',
    './dist/myproj/main-es2015.js',
  ]
  await fs.ensureDir('elements')
  await concat(files, 'elements/boa-footer.js');
  await fs.copyFile('./dist/myproj/styles.css', 'elements/styles.css')
  await fs.copy('./dist/myproj/assets/', 'elements/assets/' )
})()