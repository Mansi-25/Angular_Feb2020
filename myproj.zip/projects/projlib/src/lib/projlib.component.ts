import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-projlib',
  template: `
    <p>
      projlib works!
    </p>
  `,
  styles: []
})
export class ProjlibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
