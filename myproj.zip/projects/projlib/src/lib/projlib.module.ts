import { NgModule } from '@angular/core';
import { ProjlibComponent } from './projlib.component';
import { MessageComponent } from './message/message.component';



@NgModule({
  declarations: [ProjlibComponent, MessageComponent],
  imports: [
  ],
  exports: [ProjlibComponent]
})
export class ProjlibModule { }
