import { TestBed } from '@angular/core/testing';

import { ProjlibService } from './projlib.service';

describe('ProjlibService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProjlibService = TestBed.get(ProjlibService);
    expect(service).toBeTruthy();
  });
});
