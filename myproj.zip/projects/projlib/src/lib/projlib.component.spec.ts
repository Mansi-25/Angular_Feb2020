import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjlibComponent } from './projlib.component';

describe('ProjlibComponent', () => {
  let component: ProjlibComponent;
  let fixture: ComponentFixture<ProjlibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjlibComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjlibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
