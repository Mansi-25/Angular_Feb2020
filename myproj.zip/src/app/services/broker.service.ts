import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BrokerService {
  message= new Subject<string>();
  constructor() { }
  getMessage(): Observable<string>{
    return this.message.asObservable();
  }
  updateMessage(msg:string){
    this.message.next(msg);
  }
}
