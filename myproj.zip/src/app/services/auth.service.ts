import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private _token: string;
  get token(): string {
    return this._token;
  }
  set token(value: string) {
    this._token = value;
  }
  private _isLoggedIn: boolean;
  get isLoggedIn(): boolean {
    this._isLoggedIn=true;
    return this._isLoggedIn;
  }
  set isLoggedIn(value: boolean) {
    this._isLoggedIn = value;
  }
  constructor() { }
  logout()
  {
    window.sessionStorage.removeItem("token");
  }
}
