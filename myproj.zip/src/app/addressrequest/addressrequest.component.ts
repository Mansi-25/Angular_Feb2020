import { Component, OnInit } from '@angular/core';
import { BrokerService } from '../services/broker.service';
import { Observable, fromEvent } from 'rxjs';

@Component({
  selector: 'app-addressrequest',
  templateUrl: './addressrequest.component.html',
  styleUrls: ['./addressrequest.component.css']
})
export class AddressrequestComponent implements OnInit {

  name: 'Angular';
  constructor(private brokerService: BrokerService) { }

  ngOnInit() {
  }
  passInputData() {
    var button = document.querySelector('button');
    var keyups = fromEvent(button, 'click')
      .subscribe(value => {
        console.log(value);
        if (value.type === 'click') {
          console.log('input value: ', this.name);
          this.brokerService.updateMessage(this.name);
        }
      });
  }
}
