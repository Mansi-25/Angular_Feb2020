import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from '@angular/material/form-field' ;
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginService } from './services/login.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { MenuService } from './services/menu.service';
import { HomeComponent } from './home/home.component';
import {TieredMenuModule} from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { RequestsComponent } from './requests/requests.component';
import { ChequerequestComponent } from './chequerequest/chequerequest.component';
import { AddressrequestComponent } from './addressrequest/addressrequest.component';
import {MatTableModule} from '@angular/material/table';
import {MatSortModule} from '@angular/material/sort';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatDialogModule} from '@angular/material/dialog';
import { EditComponent } from './transactions/edit/edit.component';
import { EditviewComponent } from './transactions/editview/editview.component';
import { FooterComponent } from './footer/footer.component';
import {createCustomElement} from '@angular/elements';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment'
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import {MatListModule} from '@angular/material/list';
import {OAuthModule} from 'angular-oauth2-oidc';
import { RegisterComponent } from './register/register.component';
import { EqualValidator } from './register/matchvalidator';
import { UserService } from './services/user.service';
import {MatSnackBarModule} from '@angular/material/snack-bar';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    TransactionsComponent,
    RequestsComponent,
    ChequerequestComponent,
    AddressrequestComponent,
    EditComponent,
    EditviewComponent,
    FooterComponent,
    RegisterComponent,
    EqualValidator
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    MatListModule,
    OAuthModule.forRoot(),
    ReactiveFormsModule
  ],
  providers: [LoginService, AuthService, MenuService,UserService,{
    provide: LocationStrategy, useClass: HashLocationStrategy
  }],
  entryComponents: [EditComponent,EditviewComponent,FooterComponent],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(private injector: Injector){
    const customElement = createCustomElement(FooterComponent,{injector});
    customElements.define('boa-footer',customElement);
  }
  ngDoBootstrap(){

  }
}

