import { Component, OnInit, Input } from '@angular/core';
import { BrokerService } from '../services/broker.service';
import {Subscription} from "rxjs";


@Component({
  selector: 'app-chequerequest',
  templateUrl: './chequerequest.component.html',
  styleUrls: ['./chequerequest.component.css']
})
export class ChequerequestComponent implements OnInit {

  @Input() name: string;
  subscription: Subscription;
  currdate:Date=new Date();
  messagefromSibling: string[]=[];
  constructor(private brokerService: BrokerService) {
    console.log(this.messagefromSibling);
    this.subscription = this.brokerService.getMessage()
      .subscribe(message=> {
        console.log('Getting value from Data Sending component: ', message);

        this.messagefromSibling.push(message);
        this.currdate=new Date();
      });
  }
  ngOnInit() {

  }
}
